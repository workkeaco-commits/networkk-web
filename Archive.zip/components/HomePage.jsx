"use client"; // required because it uses hooks + framer-motion
import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Search, Star, CheckCircle } from "lucide-react";

// --- Sample data (replace with real API data later) ---
const FREELANCERS = [
  {
    id: 1,
    name: "Mariam El‑Sayed",
    title: "Senior UI/UX Designer",
    skills: ["Figma", "Design Systems", "Prototyping"],
  },
  {
    id: 2,
    name: "Omar Hassan",
    title: "Full‑Stack Developer",
    skills: ["React", "Node.js", "PostgreSQL"],
  },
  {
    id: 3,
    name: "Sara Nabil",
    title: "Data Scientist",
    skills: ["Python", "Pandas", "XGBoost"],
  },
  {
    id: 4,
    name: "Youssef Magdy",
    title: "Mobile Engineer",
    skills: ["React Native", "Expo", "Firebase"],
  },
  {
    id: 5,
    name: "Nour El‑Din",
    title: "Product Manager",
    skills: ["Roadmapping", "A/B Testing", "Analytics"],
  },
  {
    id: 6,
    name: "Laila Farouk",
    title: "DevOps Engineer",
    skills: ["Docker", "Kubernetes", "CI/CD"],
  },
];

const fadeUp = {
  initial: { opacity: 0, y: 16 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, ease: "easeOut" },
};

function SectionWrapper({ children, className = "" }) {
  return (
    <section className={`w-full py-12 md:py-16 ${className}`}>
      <div className="max-w-6xl mx-auto px-4 md:px-6">{children}</div>
    </section>
  );
}

function Pill({ children }) {
  return (
    <span className="inline-flex items-center rounded-full border border-neutral-300 px-3 py-1 text-sm leading-6">
      {children}
    </span>
  );
}

function Card({ children }) {
  return (
    <div className="rounded-2xl bg-white shadow-sm ring-1 ring-black/5 p-5 md:p-6">
      {children}
    </div>
  );
}

function Avatar({ name }) {
  const initials = useMemo(() =>
    name
      .split(" ")
      .map((n) => n[0])
      .slice(0, 2)
      .join("")
      .toUpperCase(),
  [name]);
  return (
    <div className="h-12 w-12 shrink-0 rounded-full bg-black text-white grid place-items-center text-sm font-semibold">
      {initials}
    </div>
  );
}

export default function HomePage() {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return FREELANCERS;
    return FREELANCERS.filter((f) => {
      const inName = f.name.toLowerCase().includes(q);
      const inTitle = f.title.toLowerCase().includes(q);
      const inSkills = f.skills.some((s) => s.toLowerCase().includes(q));
      return inName || inTitle || inSkills;
    });
  }, [query]);

  return (
    <main className="bg-white text-neutral-900 antialiased">
      {/* HERO */}
      <SectionWrapper>
        <motion.div
          {...fadeUp}
          className="rounded-2xl bg-neutral-100 p-8 md:p-12 ring-1 ring-black/5"
        >
          <div className="flex flex-col gap-6 md:gap-8">
            <div className="max-w-2xl">
              <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-3">
                About us
              </h1>
              <p className="text-base md:text-lg leading-7">
               Networkk is Egypt’s marketplace for remote work, using our network of skilled professionals to help businesses hire easily. We make finding the right talent simple, reliable, and secure, including hassle-free payments.

              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <Pill><Star className="h-4 w-4 mr-2" />Vetted talent</Pill>
              <Pill><CheckCircle className="h-4 w-4 mr-2" />Secure payments</Pill>
              <Pill>24‑48h matching</Pill>
            </div>
          </div>
        </motion.div>
      </SectionWrapper>

      {/* FREELANCERS */}
      <SectionWrapper>
        <motion.div
          {...fadeUp}
          className="rounded-2xl bg-neutral-100 p-6 md:p-8 ring-1 ring-black/5"
        >
          <div className="mb-6 md:mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <h2 className="text-2xl md:text-3xl font-semibold tracking-tight">
              Featured freelancers
            </h2>
            <div className="relative w-full md:w-80">
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search by name, title, or skill…"
                className="w-full rounded-xl border border-neutral-300 bg-white pl-10 pr-3 py-2.5 outline-none focus:ring-2 focus:ring-neutral-900"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-neutral-500" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
            {filtered.map((f) => (
              <Card key={f.id}>
                <div className="flex items-start gap-4">
                  <Avatar name={f.name} />
                  <div className="min-w-0">
                    <h3 className="font-semibold text-lg truncate">{f.name}</h3>
                    <p className="text-sm text-neutral-600 mb-3">{f.title}</p>
                    <div className="flex flex-wrap gap-2">
                      {f.skills.map((s) => (
                        <span
                          key={s}
                          className="rounded-full bg-neutral-100 border border-neutral-300 px-3 py-1 text-xs"
                        >
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </motion.div>
      </SectionWrapper>

      {/* HOW IT WORKS */}
      <SectionWrapper>
        <motion.div
          {...fadeUp}
          className="rounded-2xl bg-neutral-100 p-8 md:p-10 ring-1 ring-black/5"
        >
          <h2 className="text-2xl md:text-3xl font-semibold tracking-tight mb-8">
            How it works
          </h2>

          <ol className="grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-6 list-decimal list-inside">
            <li>
              <Card>
                <div className="space-y-2">
                  <h3 className="font-semibold text-lg">Post your job</h3>
                  <p className="text-sm text-neutral-700">
                    Share what you need, your timeline, and budget. Keep it simple—
                    we’ll do the heavy lifting.
                  </p>
                </div>
              </Card>
            </li>
            <li>
              <Card>
                <div className="space-y-2">
                  <h3 className="font-semibold text-lg">Match in hours</h3>
                  <p className="text-sm text-neutral-700">
                    We surface the best‑fit freelancers based on skills, past work,
                    and availability.
                  </p>
                </div>
              </Card>
            </li>
            <li>
              <Card>
                <div className="space-y-2">
                  <h3 className="font-semibold text-lg">Hire & pay securely</h3>
                  <p className="text-sm text-neutral-700">
                    Contract, track progress, and pay securely (e.g., Paymob) from
                    one dashboard.
                  </p>
                </div>
              </Card>
            </li>
          </ol>
        </motion.div>
      </SectionWrapper>

      <footer className="py-10">
        <div className="max-w-6xl mx-auto px-4 md:px-6 text-sm text-neutral-500">
          © {new Date().getFullYear()} Networkk. All rights reserved.
        </div>
      </footer>
    </main>
  );
}
