"use client";

import {
  useEffect,
  useState,
  FormEvent,
  KeyboardEvent,
  useRef,
} from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase/browser";

/* ----------------- helpers ----------------- */

function sumMilestones(ms: Array<{ amount_gross?: number | null }>) {
  return (ms || []).reduce(
    (a, m) => a + (Number(m?.amount_gross ?? 0) || 0),
    0
  );
}

/* ----------------- types (existing) ----------------- */

type Conversation = {
  id: string;
  job_post_id: number;
  created_at: string;
  last_message_at: string | null;
  job_posts?: {
    title: string | null;
  } | null;
};

type MessageRow = {
  id: string;
  conversation_id: string;
  sender_auth_id: string;
  sender_role: "freelancer" | "client" | "admin";
  body: string;
  created_at: string;
};

type Freelancer = {
  freelancer_id: number;
  full_name: string | null;
};

/* ----------------- types (new) ----------------- */

type ProposalLite = {
  proposal_id: number;
  offered_by: "client" | "freelancer";
  status:
    | "sent"
    | "countered"
    | "pending"
    | "accepted"
    | "rejected"
    | "superseded"
    | "cancelled";
  currency: string | null;
  platform_fee_percent: number | null;
  message: string | null;
  created_at: string;
  conversation_id: string | null;
  proposal_milestones: Array<{
    position: number;
    title: string | null;
    amount_gross: number | null;
    duration_days: number | null;
  }>;
};

/* ----------------- Offer modal ----------------- */

function OfferViewerModal({
  open,
  onClose,
  proposal,
  conversationId,
  currentUserId,
}: {
  open: boolean;
  onClose: () => void;
  proposal: ProposalLite | null;
  conversationId: string | null;
  currentUserId: string | null;
}) {
  const [editing, setEditing] = useState(false);
  const [rows, setRows] = useState<
    Array<{ title: string; amount: string; days: string }>
  >([]);

  useEffect(() => {
    if (!open) {
      setEditing(false);
      setRows([]);
      return;
    }
    if (proposal) {
      const base = (proposal.proposal_milestones || [])
        .slice()
        .sort((a, b) => a.position - b.position)
        .map((m) => ({
          title: m.title || "",
          amount: String(m.amount_gross ?? ""),
          days: String(m.duration_days ?? ""),
        }));
      setRows(base.length ? base : [{ title: "", amount: "", days: "" }]);
    }
  }, [open, proposal]);

  if (!open) return null;

  const currency = proposal?.currency || "EGP";
  const total = sumMilestones(proposal?.proposal_milestones || []);

  const addRow = () =>
    setRows((r) => [...r, { title: "", amount: "", days: "" }]);
  const removeRow = (i: number) =>
    setRows((r) => (r.length > 1 ? r.filter((_, idx) => idx !== i) : r));
  const updateRow = (i: number, k: "title" | "amount" | "days", v: string) =>
    setRows((r) => {
      const c = [...r];
      c[i] = { ...c[i], [k]: k === "title" ? v : v.replace(/[^\d]/g, "") };
      return c;
    });

  const acceptOffer = async () => {
    if (!proposal) return;
    try {
      const res = await fetch(`/api/proposals/${proposal.proposal_id}/respond`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "accept", actor: "freelancer" }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || "Failed to accept");

      // Optional: drop a small system message in chat
      if (conversationId && currentUserId) {
        await supabase.from("messages").insert({
          conversation_id: conversationId,
          sender_auth_id: currentUserId,
          sender_role: "freelancer",
          body: `Offer accepted (Proposal #${proposal.proposal_id}).`,
        });
        await supabase
          .from("conversations")
          .update({ last_message_at: new Date().toISOString() })
          .eq("id", conversationId);
      }

      onClose();
    } catch (e: any) {
      alert(e.message || "Failed to accept");
    }
  };

  const sendCounter = async () => {
    if (!proposal) return;
    const ms = rows
      .map((r, i) => ({
        order: i + 1,
        title: r.title.trim(),
        amount: Number(r.amount || 0),
        days: Number(r.days || 0),
      }))
      .filter((m) => m.title && m.amount > 0);

    if (!ms.length) {
      alert("Add at least one milestone with a title and amount.");
      return;
    }

    try {
      const res = await fetch(`/api/proposals/${proposal.proposal_id}/counter`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          actor: "freelancer",
          milestones: ms,
          message: "Counter offer from freelancer via chat",
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || "Failed to send counter");

      // Optional: system message
      if (conversationId && currentUserId) {
        await supabase.from("messages").insert({
          conversation_id: conversationId,
          sender_auth_id: currentUserId,
          sender_role: "freelancer",
          body: `Counter offer sent (Proposal #${json.proposal_id || proposal.proposal_id}).`,
        });
        await supabase
          .from("conversations")
          .update({ last_message_at: new Date().toISOString() })
          .eq("id", conversationId);
      }

      onClose();
    } catch (e: any) {
      alert(e.message || "Failed to send counter");
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-2xl bg-white p-5 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-base font-semibold text-slate-900">
            {editing ? "Edit & send counter" : "Offer from client"}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="text-xl leading-none text-slate-400 hover:text-slate-600"
          >
            ×
          </button>
        </div>

        {!proposal ? (
          <p className="text-sm text-slate-600">No active offer found.</p>
        ) : !editing ? (
          <div className="space-y-4">
            <div className="rounded-xl border border-slate-200 p-3 bg-slate-50">
              <p className="text-sm text-slate-800">
                {proposal.message || "New offer"}
              </p>
              <p className="mt-1 text-xs text-slate-500">
                Currency: {currency} • Platform fee:{" "}
                {proposal.platform_fee_percent ?? 10}%
              </p>
            </div>

            <div className="space-y-2">
              <h4 className="text-sm font-medium text-slate-900">
                Milestones
              </h4>
              <div className="space-y-2">
                {proposal.proposal_milestones
                  .slice()
                  .sort((a, b) => a.position - b.position)
                  .map((m) => (
                    <div
                      key={m.position}
                      className="flex items-center justify-between rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm"
                    >
                      <div className="text-slate-800">
                        {m.title || `Milestone #${m.position}`}
                        <span className="ml-2 text-xs text-slate-500">
                          {m.duration_days ? `• ${m.duration_days} days` : ""}
                        </span>
                      </div>
                      <div className="text-slate-900 font-medium">
                        {currency} {(m.amount_gross ?? 0).toLocaleString()}
                      </div>
                    </div>
                  ))}
              </div>

              <div className="flex items-center justify-end pt-1">
                <span className="text-sm text-slate-600 mr-2">Total:</span>
                <span className="text-sm font-semibold text-slate-900">
                  {currency} {total.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium text-slate-900">
                Edit milestones
              </h4>
              <button
                type="button"
                onClick={addRow}
                className="text-xs font-medium text-emerald-600 hover:text-emerald-700"
              >
                + Add
              </button>
            </div>
            <div className="space-y-2">
              {rows.map((r, i) => (
                <div
                  key={i}
                  className="grid gap-2 sm:grid-cols-3 rounded-xl border border-slate-200 bg-slate-50 p-3"
                >
                  <input
                    value={r.title}
                    onChange={(e) => updateRow(i, "title", e.target.value)}
                    className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs"
                    placeholder={`Milestone #${i + 1} title`}
                  />
                  <input
                    value={r.amount}
                    onChange={(e) => updateRow(i, "amount", e.target.value)}
                    className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs"
                    placeholder="Amount"
                  />
                  <div className="flex gap-2">
                    <input
                      value={r.days}
                      onChange={(e) => updateRow(i, "days", e.target.value)}
                      className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs"
                      placeholder="Days"
                    />
                    {rows.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeRow(i)}
                        className="text-xs text-slate-400 hover:text-red-500"
                        title="Remove"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex justify-end gap-2 pt-3">
          {!editing ? (
            <>
              <button
                type="button"
                onClick={() => setEditing(true)}
                className="rounded-full border border-slate-300 px-3 py-1.5 text-xs"
              >
                Edit & Counter
              </button>
              <button
                type="button"
                onClick={acceptOffer}
                className="rounded-full bg-emerald-500 px-4 py-1.5 text-xs font-medium text-white hover:bg-emerald-600"
              >
                Accept offer
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => setEditing(false)}
                className="rounded-full border border-slate-300 px-3 py-1.5 text-xs"
              >
                Cancel edit
              </button>
              <button
                type="button"
                onClick={sendCounter}
                className="rounded-full bg-emerald-500 px-4 py-1.5 text-xs font-medium text-white hover:bg-emerald-600"
              >
                Send counter
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

/* ----------------- Page (your original + minimal additions) ----------------- */

export default function FreelancerMessagesPage() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [authChecking, setAuthChecking] = useState(true);
  const [freelancer, setFreelancer] = useState<Freelancer | null>(null);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loadingConversations, setLoadingConversations] = useState(true);
  const [selectedConversation, setSelectedConversation] =
    useState<Conversation | null>(null);

  const [messages, setMessages] = useState<MessageRow[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [newMessage, setNewMessage] = useState("");

  const [newConversationIds, setNewConversationIds] = useState<
    Record<string, boolean>
  >({});

  // NEW: proposal state
  const [activeProposal, setActiveProposal] = useState<ProposalLite | null>(
    null
  );
  const [offerOpen, setOfferOpen] = useState(false);

  // For auto-scroll to latest message
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // === 1) Auth guard + freelancer info ===
  useEffect(() => {
    let cancelled = false;

    const checkAuth = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (cancelled) return;

      if (!user) {
        router.replace("/freelancer/sign-in?next=/freelancer/messages");
        return;
      }

      setCurrentUserId(user.id);

      const { data, error } = await supabase
        .from("freelancers")
        .select("freelancer_id, full_name")
        .eq("auth_user_id", user.id)
        .single();

      if (cancelled) return;

      if (error || !data) {
        console.error("Freelancer profile not found", error);
        router.replace("/freelancer/sign-in?next=/freelancer/messages");
        return;
      }

      setFreelancer(data as Freelancer);
      setAuthChecking(false);
    };

    checkAuth();

    return () => {
      cancelled = true;
    };
  }, [router]);

  // === 2) Load conversations for this freelancer ===
  useEffect(() => {
    if (authChecking || !freelancer) return;

    let cancelled = false;

    const loadConversations = async () => {
      setLoadingConversations(true);

      const { data, error } = await supabase
        .from("conversations")
        .select(
          `
          id,
          job_post_id,
          created_at,
          last_message_at,
          job_posts:job_post_id (
            title
          )
        `
        )
        .eq("freelancer_id", freelancer.freelancer_id)
        .order("last_message_at", { ascending: false, nullsLast: true });

      if (cancelled) return;

      if (error) {
        console.error("Error loading conversations", error);
        setConversations([]);
        setLoadingConversations(false);
        return;
      }

      const convs = (data || []) as Conversation[];
      setConversations(convs);
      setLoadingConversations(false);

      const qsId = searchParams.get("conversation");
      if (qsId) {
        const found = convs.find((c) => c.id === qsId);
        setSelectedConversation(found || convs[0] || null);
      } else {
        setSelectedConversation(convs[0] || null);
      }
    };

    loadConversations();

    return () => {
      cancelled = true;
    };
  }, [authChecking, freelancer, searchParams]);

  // === 3) Realtime: conversations (INSERT + DELETE) ===
  useEffect(() => {
    if (!freelancer) return;

    const channel = supabase
      .channel(`freelancer-conversations-${freelancer.freelancer_id}`)

      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "conversations",
          filter: `freelancer_id=eq.${freelancer.freelancer_id}`,
        },
        async (payload) => {
          const newId = (payload.new as any).id as string;

          const { data, error } = await supabase
            .from("conversations")
            .select(
              `
              id,
              job_post_id,
              created_at,
              last_message_at,
              job_posts:job_post_id (
                title
              )
            `
            )
            .eq("id", newId)
            .single();

          if (error || !data) {
            console.error("Error fetching new conversation", error);
            return;
          }

          const conv = data as Conversation;

          setConversations((prev) => {
            if (prev.some((c) => c.id === conv.id)) return prev;
            return [conv, ...prev];
          });

          setNewConversationIds((prev) => ({
            ...prev,
            [conv.id]: true,
          }));

          setSelectedConversation((current) => current ?? conv);
        }
      )

      .on(
        "postgres_changes",
        {
          event: "DELETE",
          schema: "public",
          table: "conversations",
          filter: `freelancer_id=eq.${freelancer.freelancer_id}`,
        },
        (payload) => {
          const deletedId = (payload.old as any).id as string;

          setConversations((prev) => prev.filter((c) => c.id !== deletedId));

          setNewConversationIds((prev) => {
            const copy = { ...prev };
            delete copy[deletedId];
            return copy;
          });

          setMessages((prev) =>
            selectedConversation && selectedConversation.id === deletedId
              ? []
              : prev
          );

          setSelectedConversation((current) => {
            if (!current || current.id !== deletedId) return current;
            return null;
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [freelancer, selectedConversation]);

  // === 4) Load messages + realtime per conversation ===
  useEffect(() => {
    if (!selectedConversation) {
      setMessages([]);
      setActiveProposal(null); // reset offer
      return;
    }

    let cancelled = false;

    const loadMessages = async () => {
      setLoadingMessages(true);
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .eq("conversation_id", selectedConversation.id)
        .order("created_at", { ascending: true });

      if (cancelled) return;

      if (error) {
        console.error("Error loading messages", error);
        setMessages([]);
      } else {
        setMessages((data || []) as MessageRow[]);
      }

      setLoadingMessages(false);

      setNewConversationIds((prev) => {
        const copy = { ...prev };
        delete copy[selectedConversation.id];
        return copy;
      });
    };

    const loadProposal = async () => {
      // latest open proposal for this conversation
      const { data, error } = await supabase
        .from("proposals")
        .select(
          `
            proposal_id,
            offered_by,
            status,
            currency,
            platform_fee_percent,
            message,
            created_at,
            conversation_id,
            proposal_milestones:proposal_milestones (
              position, title, amount_gross, duration_days
            )
          `
        )
        .eq("conversation_id", selectedConversation.id)
        .in("status", ["sent", "countered", "pending"])
        .order("created_at", { ascending: false })
        .limit(1);

      if (!cancelled) {
        if (error) {
          console.error("Proposal fetch error:", error.message);
          setActiveProposal(null);
        } else {
          setActiveProposal((data && data[0]) || null);
        }
      }
    };

    loadMessages();
    loadProposal();

    const msgChan = supabase
      .channel(`conversation-${selectedConversation.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `conversation_id=eq.${selectedConversation.id}`,
        },
        (payload) => {
          setMessages((prev) => [...prev, payload.new as MessageRow]);
        }
      )
      .subscribe();

    // keep proposal in sync for this conversation
    const propChan = supabase
      .channel(`proposals-${selectedConversation.id}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "proposals",
          filter: `conversation_id=eq.${selectedConversation.id}`,
        },
        async () => {
          const { data } = await supabase
            .from("proposals")
            .select(
              `
                proposal_id,
                offered_by,
                status,
                currency,
                platform_fee_percent,
                message,
                created_at,
                conversation_id,
                proposal_milestones:proposal_milestones (
                  position, title, amount_gross, duration_days
                )
              `
            )
            .eq("conversation_id", selectedConversation.id)
            .in("status", ["sent", "countered", "pending"])
            .order("created_at", { ascending: false })
            .limit(1);
          setActiveProposal((data && data[0]) || null);
        }
      )
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(msgChan);
      supabase.removeChannel(propChan);
    };
  }, [selectedConversation]);

  // === 5) Auto-scroll to bottom when messages change ===
  useEffect(() => {
    if (!selectedConversation) return;
    if (!messagesEndRef.current) return;

    messagesEndRef.current.scrollIntoView({
      behavior: "smooth",
      block: "end",
    });
  }, [selectedConversation, messages.length]);

  // === 6) Mark messages seen ===
  useEffect(() => {
    if (!freelancer) return;
    if (!selectedConversation) return;
    if (messages.length === 0) return;

    const markSeen = async () => {
      try {
        await supabase.rpc("mark_messages_seen_as_freelancer");
      } catch (err) {
        console.error("mark_messages_seen_as_freelancer error", err);
      }
    };

    markSeen();
  }, [freelancer, selectedConversation, messages.length]);

  // === 7) Send message (from freelancer) ===
  const handleSend = async (e: FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedConversation || !currentUserId) return;

    const body = newMessage.trim();
    setNewMessage("");

    const { error } = await supabase.from("messages").insert({
      conversation_id: selectedConversation.id,
      sender_auth_id: currentUserId,
      sender_role: "freelancer",
      body,
    });

    if (error) {
      console.error("Error sending message", error);
      setNewMessage(body);
    } else {
      await supabase
        .from("conversations")
        .update({ last_message_at: new Date().toISOString() })
        .eq("id", selectedConversation.id);
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend(e as unknown as FormEvent);
    }
  };

  if (authChecking) {
    return (
      <main className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
        <div className="rounded-2xl bg-white border border-slate-200 shadow-sm px-6 py-4">
          <p className="text-sm text-slate-600">Checking your session…</p>
        </div>
      </main>
    );
  }

  // show button only if client has an actionable offer
  const showViewOfferButton =
    !!activeProposal &&
    activeProposal.offered_by === "client" &&
    ["sent", "countered", "pending"].includes(activeProposal.status);

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="mx-auto max-w-6xl px-4 py-8">
        <header className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-slate-900">
              Messages
            </h1>
            <p className="text-sm text-slate-500">
              Chat with clients about your job posts.
            </p>
          </div>
          <button
            type="button"
            onClick={() => router.push("/jobs")}
            className="rounded-full border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
          >
            Back to jobs
          </button>
        </header>

        <div className="grid gap-4 md:grid-cols-[260px_minmax(0,1fr)]">
          {/* Left: conversation list */}
          <aside className="rounded-2xl border border-slate-200 bg-white p-3 flex flex-col">
            <div className="mb-2 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-800">
                Conversations
              </h2>
              <span className="text-[11px] text-slate-400">
                {loadingConversations
                  ? "Loading…"
                  : `${conversations.length} chats`}
              </span>
            </div>

            {conversations.length === 0 && !loadingConversations ? (
              <p className="mt-4 text-xs text-slate-500">
                You don&apos;t have any conversations yet.
              </p>
            ) : (
              <ul className="flex-1 space-y-1 overflow-y-auto">
                {conversations.map((c) => {
                  const isActive = selectedConversation?.id === c.id;
                  const title =
                    c.job_posts?.title || `Job #${c.job_post_id}`;
                  const lastTime = c.last_message_at || c.created_at;
                  const isNew = newConversationIds[c.id];

                  return (
                    <li key={c.id}>
                      <button
                        type="button"
                        onClick={() => setSelectedConversation(c)}
                        className={`w-full rounded-xl px-3 py-2 text-left text-xs ${
                          isActive
                            ? "bg-emerald-50 border border-emerald-200"
                            : "hover:bg-slate-50 border border-transparent"
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="font-medium text-slate-900 line-clamp-2">
                            {title}
                          </div>
                          {isNew && (
                            <span className="ml-2 rounded-full bg-emerald-500 px-2 py-0.5 text-[10px] font-semibold text-white">
                              NEW
                            </span>
                          )}
                        </div>
                        <div className="mt-0.5 text-[11px] text-slate-400">
                          {new Date(lastTime).toLocaleString()}
                        </div>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </aside>

          {/* Right: messages */}
          <section className="rounded-2xl border border-slate-200 bg-white flex flex-col h-[520px]">
            {selectedConversation ? (
              <>
                <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
                  <div>
                    <p className="text-sm font-semibold text-slate-900">
                      {selectedConversation.job_posts?.title ||
                        `Job #${selectedConversation.job_post_id}`}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Chat with the client
                    </p>
                  </div>

                  {showViewOfferButton ? (
                    <button
                      type="button"
                      onClick={() => setOfferOpen(true)}
                      className="inline-flex items-center rounded-full bg-emerald-500 px-3 py-1.5 text-xs font-medium text-white shadow-sm hover:bg-emerald-600"
                    >
                      View offer
                    </button>
                  ) : (
                    <span className="text-xs text-slate-400"></span>
                  )}
                </div>

                <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
                  {loadingMessages ? (
                    <p className="text-xs text-slate-500">
                      Loading messages…
                    </p>
                  ) : messages.length === 0 ? (
                    <p className="text-xs text-slate-500">
                      No messages yet. Say hi to the client 👋
                    </p>
                  ) : (
                    messages.map((m) => {
                      const isOwn = m.sender_auth_id === currentUserId;
                      return (
                        <div
                          key={m.id}
                          className={`flex ${
                            isOwn ? "justify-end" : "justify-start"
                          }`}
                        >
                          <div
                            className={`max-w-[75%] rounded-2xl px-3 py-2 text-sm ${
                              isOwn
                                ? "bg-emerald-500 text-white"
                                : "bg-slate-100 text-slate-900"
                            }`}
                          >
                            <p className="whitespace-pre-wrap">{m.body}</p>
                            <span className="mt-1 block text-[10px] text-slate-400 text-right">
                              {new Date(m.created_at).toLocaleTimeString(
                                [],
                                { hour: "2-digit", minute: "2-digit" }
                              )}
                            </span>
                          </div>
                        </div>
                      );
                    })
                  )}
                  {/* Scroll anchor */}
                  <div ref={messagesEndRef} />
                </div>

                <form
                  onSubmit={handleSend}
                  className="border-t border-slate-200 px-4 py-3 flex items-end gap-2"
                >
                  <textarea
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={handleKeyDown}
                    rows={1}
                    placeholder="Type your message…"
                    className="flex-1 resize-none rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-emerald-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                  <button
                    type="submit"
                    className="inline-flex items-center rounded-full bg-emerald-500 px-4 py-2 text-xs font-medium text-white shadow-sm hover:bg-emerald-600 disabled:opacity-60"
                    disabled={!newMessage.trim()}
                  >
                    Send
                  </button>
                </form>
              </>
            ) : (
              <div className="flex flex-1 items-center justify-center text-sm text-slate-500">
                Select a conversation from the left to start chatting.
              </div>
            )}
          </section>
        </div>
      </div>

      {/* Offer viewer (accept / counter) */}
      <OfferViewerModal
        open={offerOpen}
        onClose={() => setOfferOpen(false)}
        proposal={activeProposal}
        conversationId={selectedConversation?.id ?? null}
        currentUserId={currentUserId}
      />
    </main>
  );
}
