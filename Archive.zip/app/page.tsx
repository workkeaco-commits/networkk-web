// app/page.jsx
import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-brand-white flex flex-col">
      {/* HERO SECTION */}
      <section className="w-full px-4 sm:px-8 lg:px-16 pt-10 pb-8">
        <div className="max-w-5xl mx-auto bg-brand-secondary rounded-3xl px-6 sm:px-10 py-12">
          <div className="text-center">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-brand-black">
              Egypt&apos;s marketplace for remote work
            </h1>
            <p className="mt-4 text-base sm:text-lg text-brand-black/70">
              Hire talented freelancers in a few clicks.
            </p>

            <div className="mt-8 flex items-center justify-center gap-4">
              {/* Primary button */}
              <Link
                href="#"
                className="inline-flex items-center justify-center rounded-full px-8 py-3 text-sm font-medium text-brand-white bg-brand-primary hover:opacity-90 transition"
              >
                Hire today
              </Link>

              {/* Secondary button */}
              <Link
                href="#"
                className="inline-flex items-center justify-center rounded-full px-8 py-3 text-sm font-medium text-brand-primary bg-brand-white border border-brand-primary/40 hover:bg-brand-secondary transition"
              >
                Apply for jobs
              </Link>
            </div>

            {/* Hero image placeholder */}
            <div className="mt-10 w-full h-64 bg-brand-white rounded-2xl flex items-center justify-center text-brand-black/30 text-sm">
              Hero image
            </div>
          </div>
        </div>
      </section>

      {/* CARDS SECTION */}
      <section className="w-full px-4 sm:px-8 lg:px-16 pb-16">
        <div className="max-w-6xl mx-auto grid gap-6 lg:grid-cols-2">
          {/* LEFT CARD */}
          <article className="bg-brand-secondary rounded-3xl p-8 flex flex-col">
            <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight text-brand-black">
              Give something special.
            </h2>
            <p className="mt-3 text-brand-black/70">
              Find what they&apos;re wishing for at year.
            </p>

            <div className="mt-6 flex gap-4">
              <button className="px-6 py-2.5 rounded-full text-sm font-medium text-brand-white bg-brand-primary hover:opacity-90 transition">
                Buy
              </button>
              <button className="px-6 py-2.5 rounded-full text-sm font-medium text-brand-primary bg-brand-white border border-brand-primary/40 hover:bg-brand-secondary transition">
                Learn more
              </button>
            </div>

            <div className="mt-8 flex-1 w-full h-56 bg-brand-white rounded-2xl flex items-center justify-center text-brand-black/30 text-sm">
              Image
            </div>
          </article>

          {/* RIGHT CARD */}
          <article className="bg-brand-secondary rounded-3xl p-8 flex flex-col">
            <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight text-brand-black">
              AirPods Pro 3
            </h2>
            <p className="mt-3 text-brand-black/70">
              The world&apos;s best in-ear headphones. Now with USB-C.
            </p>

            <div className="mt-6 flex gap-4">
              <button className="px-6 py-2.5 rounded-full text-sm font-medium text-brand-white bg-brand-primary hover:opacity-90 transition">
                Buy
              </button>
              <button className="px-6 py-2.5 rounded-full text-sm font-medium text-brand-primary bg-brand-white border border-brand-primary/40 hover:bg-brand-secondary transition">
                Learn more
              </button>
            </div>

            <div className="mt-8 flex-1 w-full h-56 bg-brand-white rounded-2xl flex items-center justify-center text-brand-black/30 text-sm">
              Image
            </div>
          </article>
        </div>
      </section>
    </main>
  );
}
