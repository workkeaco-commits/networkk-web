// app/api/negotiations/[id]/propose/route.ts
import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/supabase/server";

type Params = { id: string };

export async function POST(req: Request, ctx: { params: Promise<Params> }) {
  const { id } = await ctx.params;
  const negId = Number(id);
  try {
    const b = await req.json();
    const proposed_by = b.proposed_by === "freelancer" ? "freelancer" : "client";
    const note = (b.note ?? "").toString();
    const payload = b.payload; // raw object as shown above

    // Get current rev & lock by re-reading (no full pg tx here; simple version)
    const { data: head, error: eHead } = await supabaseAdmin
      .from("negotiations").select("current_rev_no").eq("negotiation_id", negId).single();
    if (eHead || !head) return NextResponse.json({ error: "Negotiation not found" }, { status: 404 });

    const newRev = Number(head.current_rev_no) + 1;

    // Insert revision
    const { error: eRev } = await supabaseAdmin
      .from("negotiation_revisions")
      .insert([{ negotiation_id: negId, rev_no: newRev, proposed_by, note, payload }]);
    if (eRev) return NextResponse.json({ error: eRev.message }, { status: 400 });

    // Update head
    const { error: eUpd } = await supabaseAdmin
      .from("negotiations")
      .update({
        current_rev_no: newRev,
        last_proposed_by: proposed_by,
        accepted_by_client: false,
        accepted_by_freelancer: false,
        status: "awaiting_accept",
        updated_at: new Date().toISOString(),
      })
      .eq("negotiation_id", negId);
    if (eUpd) return NextResponse.json({ error: eUpd.message }, { status: 400 });

    // Event
    const { error: eEvt } = await supabaseAdmin
      .from("negotiation_events")
      .insert([{
        negotiation_id: negId,
        rev_no: newRev,
        event_type: proposed_by === "client" ? "proposed" : "countered",
        actor_role: proposed_by
      }]);
    if (eEvt) console.warn("[neg/event] warn:", eEvt.message);

    return NextResponse.json({ ok: true, rev_no: newRev });
  } catch (e:any) {
    return NextResponse.json({ error: e.message || "Server error" }, { status: 500 });
  }
}
