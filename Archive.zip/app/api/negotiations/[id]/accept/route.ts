// app/api/negotiations/[id]/accept/route.ts
import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/supabase/server";

type Params = { id: string };

export async function POST(req: Request, ctx: { params: Promise<Params> }) {
  const { id } = await ctx.params;
  const negId = Number(id);
  try {
    const b = await req.json();
    const who = b.who === "freelancer" ? "freelancer" : "client";

    // 1) Set acceptance flag
    const flags = who === "client" ? { accepted_by_client: true } : { accepted_by_freelancer: true };
    const { data: head, error: eUpd } = await supabaseAdmin
      .from("negotiations")
      .update({ ...flags, updated_at: new Date().toISOString() })
      .eq("negotiation_id", negId)
      .select("current_rev_no, client_id, freelancer_id, job_post_id, accepted_by_client, accepted_by_freelancer")
      .single();
    if (eUpd || !head) return NextResponse.json({ error: eUpd?.message || "Negotiation not found" }, { status: 404 });

    // event
    await supabaseAdmin.from("negotiation_events").insert([{
      negotiation_id: negId,
      rev_no: head.current_rev_no,
      event_type: who === "client" ? "accepted_by_client" : "accepted_by_freelancer",
      actor_role: who
    }]);

    // 2) If both accepted, create contract from latest payload
    if (head.accepted_by_client && head.accepted_by_freelancer) {
      const { data: rev, error: eRev } = await supabaseAdmin
        .from("negotiation_revisions")
        .select("payload")
        .eq("negotiation_id", negId)
        .eq("rev_no", head.current_rev_no)
        .single();
      if (eRev || !rev) return NextResponse.json({ error: "Latest revision not found" }, { status: 400 });

      const p = rev.payload || {};
      const total = Number(p.total_price || 0);
      const currency = String(p.currency || "EGP");

      // create contract
      const { data: contract, error: eC } = await supabaseAdmin
        .from("contracts")
        .insert([{
          client_id: head.client_id,
          freelancer_id: head.freelancer_id,
          job_post_id: head.job_post_id,
          total_price: total,
          price_currency: currency,
          status: "active",
          created_at: new Date().toISOString()
        }])
        .select("contract_id")
        .single();
      if (eC || !contract) return NextResponse.json({ error: eC?.message || "Failed to create contract" }, { status: 400 });

      // expand milestones
      const ms = Array.isArray(p.milestones) ? p.milestones : [];
      if (ms.length) {
        await supabaseAdmin.from("contract_milestones").insert(
          ms.map((m: any) => ({
            contract_id: contract.contract_id,
            position: Number(m.order || 0),
            title: String(m.name || "Milestone"),
            amount: Number(m.amount || 0),
            duration_days: m.duration_days == null ? null : Number(m.duration_days),
            status: "pending"
          }))
        );
      }

      // close negotiation
      await supabaseAdmin
        .from("negotiations")
        .update({ status: "converted", contract_id: contract.contract_id, updated_at: new Date().toISOString() })
        .eq("negotiation_id", negId);

      await supabaseAdmin.from("negotiation_events").insert([{
        negotiation_id: negId,
        rev_no: head.current_rev_no,
        event_type: "converted_to_contract",
        actor_role: "admin"
      }]);

      return NextResponse.json({ ok: true, converted: true, contract_id: contract.contract_id });
    }

    return NextResponse.json({ ok: true, converted: false });
  } catch (e:any) {
    return NextResponse.json({ error: e.message || "Server error" }, { status: 500 });
  }
}
