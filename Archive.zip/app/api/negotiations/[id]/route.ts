// app/api/negotiations/[id]/route.ts
import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/supabase/server";

type Params = { id: string };

export async function GET(_req: Request, ctx: { params: Promise<Params> }) {
  const { id } = await ctx.params;
  const negId = Number(id);
  try {
    const { data: neg, error: eN } = await supabaseAdmin
      .from("negotiations")
      .select("*")
      .eq("negotiation_id", negId).single();
    if (eN || !neg) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const { data: rev, error: eR } = await supabaseAdmin
      .from("negotiation_revisions")
      .select("*")
      .eq("negotiation_id", negId)
      .eq("rev_no", neg.current_rev_no)
      .maybeSingle();

    return NextResponse.json({ negotiation: neg, current: rev });
  } catch (e:any) {
    return NextResponse.json({ error: e.message || "Server error" }, { status: 500 });
  }
}
