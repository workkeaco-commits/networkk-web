// app/api/negotiations/[id]/reject/route.ts
import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/supabase/server";

type Params = { id: string };

export async function POST(req: Request, ctx: { params: Promise<Params> }) {
  const { id } = await ctx.params;
  const negId = Number(id);
  try {
    const b = await req.json();
    const who = b.who === "freelancer" ? "freelancer" : "client";

    const { error: eUpd } = await supabaseAdmin
      .from("negotiations")
      .update({ status: "rejected", updated_at: new Date().toISOString() })
      .eq("negotiation_id", negId);
    if (eUpd) return NextResponse.json({ error: eUpd.message }, { status: 400 });

    await supabaseAdmin.from("negotiation_events").insert([{
      negotiation_id: negId,
      event_type: "rejected",
      actor_role: who
    }]);

    return NextResponse.json({ ok: true });
  } catch (e:any) {
    return NextResponse.json({ error: e.message || "Server error" }, { status: 500 });
  }
}
