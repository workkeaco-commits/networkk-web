// app/api/negotiations/upsert/route.ts
import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/supabase/server";

export async function POST(req: Request) {
  try {
    const b = await req.json();
    const client_id = Number(b.client_id);
    const freelancer_id = Number(b.freelancer_id);
    const job_post_id = b.job_post_id == null ? null : Number(b.job_post_id);
    if (!client_id || !freelancer_id) return NextResponse.json({ error: "client_id & freelancer_id required" }, { status: 400 });

    // Try insert; if conflict (already one active), just return that one
    const { data: ins, error: eIns } = await supabaseAdmin
      .from("negotiations")
      .insert([{ client_id, freelancer_id, job_post_id, status: "open" }])
      .select("negotiation_id")
      .single();

    if (!eIns && ins) return NextResponse.json({ negotiation_id: ins.negotiation_id });

    // Fallback: fetch existing active
    const { data: existing, error: eSel } = await supabaseAdmin
      .from("negotiations")
      .select("negotiation_id")
      .eq("client_id", client_id)
      .eq("freelancer_id", freelancer_id)
      .eq("job_post_id", job_post_id)
      .in("status", ["open", "awaiting_accept"])
      .limit(1)
      .maybeSingle();

    if (eSel || !existing) return NextResponse.json({ error: eSel?.message || "Failed to upsert negotiation" }, { status: 400 });

    return NextResponse.json({ negotiation_id: existing.negotiation_id });
  } catch (e:any) {
    return NextResponse.json({ error: e.message || "Server error" }, { status: 500 });
  }
}
