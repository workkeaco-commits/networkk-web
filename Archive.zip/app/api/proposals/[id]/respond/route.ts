import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/supabase/server";

export async function POST(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { action, actor } = await req.json(); // action: 'accept'|'reject', actor: 'client'|'freelancer'
    const id = Number(params.id);

    if (action === "reject") {
      const { error } = await supabaseAdmin
        .from("proposals")
        .update({ status: "rejected", rejected_by: actor, decided_at: new Date().toISOString() })
        .eq("proposal_id", id);
      if (error) return NextResponse.json({ error: error.message }, { status: 400 });
      return NextResponse.json({ ok: true });
    }

    if (action === "accept") {
      const patch =
        actor === "client"
          ? { accepted_by_client: true }
          : { accepted_by_freelancer: true };

      const { error } = await supabaseAdmin
        .from("proposals")
        .update(patch)
        .eq("proposal_id", id);
      if (error) return NextResponse.json({ error: error.message }, { status: 400 });
      // The trigger will create a contract automatically once both flags are true.
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || "server error" }, { status: 500 });
  }
}
