// app/api/proposals/create/route.ts
import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/supabase/server";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const job_post_id = Number(body.job_post_id);
    const client_id = Number(body.client_id);
    const freelancer_id = Number(body.freelancer_id);
    const conversation_id = body.conversation_id ?? null; // nullable
    const origin = String(body.origin || "chat"); // 'chat' | 'dashboard' | etc.
    const offered_by = String(body.offered_by || "client"); // 'client' | 'freelancer'
    const currency = String(body.currency || "EGP");
    const platform_fee_percent = Number(
      body.platform_fee_percent ?? 10
    );

    const milestones = Array.isArray(body.milestones) ? body.milestones : [];

    // 1) total_gross: sum milestones if provided; else use body.total_gross/body.total_price
    const sumFromMilestones = milestones.reduce((acc: number, m: any) => {
      const amt = Number(m.amount || m.amount_gross || 0);
      return acc + (Number.isFinite(amt) ? amt : 0);
    }, 0);

    const total_gross_raw =
      sumFromMilestones > 0
        ? sumFromMilestones
        : Number(body.total_gross ?? body.total_price ?? 0);

    const total_gross = Number(total_gross_raw.toFixed(2));
    if (!Number.isFinite(total_gross) || total_gross <= 0) {
      return NextResponse.json(
        { error: "total_gross must be > 0 (either pass it or provide milestones with amounts)." },
        { status: 400 }
      );
    }

    const fee_amount = Number(((total_gross * platform_fee_percent) / 100).toFixed(2));
    const total_net = Number((total_gross - fee_amount).toFixed(2));

    // (optional) prevent multiple open proposals for the same trio
    const { data: openExists } = await supabaseAdmin
      .from("proposals")
      .select("proposal_id,status")
      .eq("client_id", client_id)
      .eq("freelancer_id", freelancer_id)
      .eq("job_post_id", job_post_id)
      .in("status", ["sent", "countered", "pending"])
      .maybeSingle();

    if (openExists) {
      return NextResponse.json(
        { ok: true, proposal_id: openExists.proposal_id, reused: true },
        { status: 200 }
      );
    }

    // 2) insert proposal (now includes total_gross and total_net)
    const { data: p, error: e1 } = await supabaseAdmin
      .from("proposals")
      .insert([{
        job_post_id,
        client_id,
        freelancer_id,
        conversation_id,         // nullable OK
        origin,                   // 'chat' | 'dashboard' | ...
        offered_by,               // 'client' | 'freelancer'
        currency,
        platform_fee_percent,
        total_gross,
        total_net,
        status: "sent",
        message: String(body.message || "")
      }])
      .select("proposal_id")
      .single();

    if (e1) {
      return NextResponse.json({ error: e1.message }, { status: 400 });
    }

    // 3) insert milestones (if any)
    if (milestones.length) {
      const rows = milestones.map((m: any, i: number) => ({
        proposal_id: p!.proposal_id,
        position: Number(m.order ?? i + 1),
        title: String(m.title || `Milestone ${i + 1}`),
        amount_gross: Number(m.amount ?? m.amount_gross ?? 0),
        duration_days: Number(m.days ?? m.duration_days ?? 0),
      }));

      const { error: e2 } = await supabaseAdmin
        .from("proposal_milestones")
        .insert(rows);

      if (e2) {
        return NextResponse.json({ error: e2.message }, { status: 400 });
      }
    }

    return NextResponse.json({ ok: true, proposal_id: p!.proposal_id }, { status: 200 });
  } catch (err: any) {
    console.error("[proposals/create] fatal:", err);
    return NextResponse.json(
      { error: err?.message || "Server error" },
      { status: 500 }
    );
  }
}
