// app/api/proposals/latest/route.ts
import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/supabase/server";

export async function GET(req: NextRequest) {
  const conversation_id = req.nextUrl.searchParams.get("conversation_id");
  if (!conversation_id) {
    return NextResponse.json({ error: "conversation_id required" }, { status: 400 });
  }

  const { data, error } = await supabaseAdmin
    .from("proposals")
    .select("proposal_id,total_gross,total_net,platform_fee_percent,currency,status,offered_by,created_at")
    .eq("conversation_id", conversation_id)
    .in("status", ["sent", "countered", "pending"])
    .order("created_at", { ascending: false })
    .limit(1)
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }

  return NextResponse.json({ proposal: data }, { status: 200 });
}
