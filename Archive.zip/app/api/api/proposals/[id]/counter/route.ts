import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/supabase/server";

export async function POST(req: Request, { params }: { params: { id: string } }) {
  try {
    const oldId = Number(params.id);
    const body = await req.json();
    const { actor, currency = "EGP", platform_fee_percent = 10, message = "", milestones = [] } = body; // actor: 'client'|'freelancer'

    // Load old proposal to inherit thread data
    const { data: old, error: eOld } = await supabaseAdmin
      .from("proposals")
      .select("proposal_id, root_proposal_id, job_post_id, client_id, freelancer_id")
      .eq("proposal_id", oldId)
      .single();
    if (eOld || !old) return NextResponse.json({ error: "Old proposal not found" }, { status: 404 });

    // Close the old one
    await supabaseAdmin
      .from("proposals")
      .update({ status: "superseded", decided_at: new Date().toISOString() })
      .eq("proposal_id", oldId);

    const total_gross = milestones.reduce((s: number, m: any) => s + Number(m.amount_gross || 0), 0);

    // New proposal
    const { data: prop, error: eIns } = await supabaseAdmin
      .from("proposals")
      .insert({
        job_post_id: old.job_post_id,
        client_id: old.client_id,
        freelancer_id: old.freelancer_id,
        origin: "chat",
        offered_by: actor,
        currency,
        total_gross,
        platform_fee_percent,
        message,
        status: "counter",
        supersedes_proposal_id: old.proposal_id,
        root_proposal_id: old.root_proposal_id || old.proposal_id,
        accepted_by_client: false,
        accepted_by_freelancer: false,
      })
      .select("proposal_id")
      .single();
    if (eIns || !prop) return NextResponse.json({ error: eIns?.message || "insert failed" }, { status: 400 });

    const pid = prop.proposal_id;

    if (milestones.length) {
      const rows = milestones.map((m: any, i: number) => ({
        proposal_id: pid,
        title: m.title,
        amount_gross: Number(m.amount_gross || 0),
        duration_days: m.duration_days ?? null,
        position: m.position ?? i + 1,
      }));
      const { error: eMil } = await supabaseAdmin.from("proposal_milestones").insert(rows);
      if (eMil) return NextResponse.json({ error: eMil.message }, { status: 400 });
    }

    return NextResponse.json({ ok: true, proposal_id: pid });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || "server error" }, { status: 500 });
  }
}
