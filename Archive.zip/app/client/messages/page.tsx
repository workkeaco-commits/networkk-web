"use client";

import {
  useEffect,
  useState,
  FormEvent,
  KeyboardEvent,
  useRef,
} from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { supabase } from "@/lib/supabase/browser";

/* ---------------- Helpers ---------------- */

function initials(name?: string | null) {
  if (!name) return "F";
  const parts = name.trim().split(/\s+/).slice(0, 2);
  return parts.map((p) => p[0]?.toUpperCase() || "").join("") || "F";
}

function displayFreelancerName(f?: {
  first_name?: string | null;
  last_name?: string | null;
  full_name?: string | null;
}) {
  return (
    f?.full_name ||
    [f?.first_name, f?.last_name].filter(Boolean).join(" ") ||
    "Freelancer"
  );
}

/* ---------------- Types ---------------- */

type Conversation = {
  id: string;
  job_post_id: number;
  freelancer_id?: number | null;
  created_at: string;
  last_message_at: string | null;
  job_posts?: { title: string | null } | null;
  freelancer?: {
    full_name?: string | null;
    first_name?: string | null;
    last_name?: string | null;
    personal_img_url: string | null;
  } | null;
};

type MessageRow = {
  id: string;
  conversation_id: string;
  sender_auth_id: string;
  sender_role: "freelancer" | "client" | "admin";
  body: string;
  created_at: string;
};

type Client = {
  client_id: number;
  full_name?: string | null;
};

/* ---------------- Offer modal ---------------- */

type Milestone = { title: string; amount: string; days: string };

function OfferInlineModal({
  open,
  onClose,
  clientId,
  freelancerId,
  jobPostId,
  conversationId,
  currentUserId,
}: {
  open: boolean;
  onClose: () => void;
  clientId: number | null;
  freelancerId: number | null;
  jobPostId: number | null;
  conversationId: string | null;
  currentUserId: string | null;
}) {
  const [totalPrice, setTotalPrice] = useState("");
  const [currency, setCurrency] = useState("EGP");
  const [milestones, setMilestones] = useState<Milestone[]>([
    { title: "", amount: "", days: "" },
  ]);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!open) {
      setTotalPrice("");
      setCurrency("EGP");
      setMilestones([{ title: "", amount: "", days: "" }]);
      setSubmitting(false);
    }
  }, [open]);

  if (!open) return null;

  const missing: string[] = [];
  if (!clientId) missing.push("client");
  if (!freelancerId) missing.push("freelancer");
  if (!jobPostId) missing.push("job post");
  if (!conversationId) missing.push("conversation");

  const addMilestone = () =>
    setMilestones((m) => [...m, { title: "", amount: "", days: "" }]);
  const removeMilestone = (idx: number) =>
    setMilestones((m) => (m.length > 1 ? m.filter((_, i) => i !== idx) : m));
  const updateMilestone = (idx: number, key: keyof Milestone, val: string) =>
    setMilestones((m) => {
      const c = [...m];
      c[idx] = { ...c[idx], [key]: val };
      return c;
    });

  const handleSubmit = async () => {
    try {
      if (missing.length) {
        alert(`Missing ${missing.join(", ")} to send an offer.`);
        return;
      }

      const totalNum = Number(totalPrice || 0);
      const ms = milestones
        .map((m, i) => ({
          order: i + 1,
          title: (m.title || "").trim(),
          amount: Number(m.amount || 0),
          days: Number(m.days || 0),
        }))
        .filter((m) => m.title && m.amount > 0);

      if (!ms.length) {
        alert("Add at least one milestone with a title and amount.");
        return;
      }

      setSubmitting(true);

      // ---- payload exactly as requested
      const payload = {
        job_post_id: jobPostId!,
        client_id: clientId!,
        freelancer_id: freelancerId!,
        conversation_id: conversationId!,       // <-- NEW
        origin: "chat" as const,                // <-- now allowed
        offered_by: "client" as const,
        currency,
        platform_fee_percent: 10,
        message: "Initial offer from client via chat",
        milestones: ms, // [{order,title,amount,days}, ...]
      };

      const res = await fetch("/api/proposals/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || "Failed to send offer");

      // optional: post a lightweight system message into the chat
      if (currentUserId) {
        const sys = `Offer sent: Proposal #${json.proposal_id} • Total ${currency} ${totalNum.toLocaleString()}`;
        const { error: eMsg } = await supabase.from("messages").insert({
          conversation_id: conversationId!,
          sender_auth_id: currentUserId,
          sender_role: "client",
          body: sys,
        });
        if (!eMsg) {
          await supabase
            .from("conversations")
            .update({ last_message_at: new Date().toISOString() })
            .eq("id", conversationId!);
        }
      }

      alert("Offer sent.");
      onClose();
    } catch (e: any) {
      alert(e.message || "Failed to send offer");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-2xl bg-white p-5 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-base font-semibold text-slate-900">
            Create offer / contract
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="text-xl leading-none text-slate-400 hover:text-slate-600"
          >
            ×
          </button>
        </div>

        {!!missing.length && (
          <p className="mb-3 text-xs text-red-600">
            Missing: {missing.join(", ")} — cannot submit yet.
          </p>
        )}

        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-2">
            <div className="col-span-2">
              <label className="block text-xs text-slate-500 mb-1">
                Total price
              </label>
              <input
                value={totalPrice}
                onChange={(e) =>
                  setTotalPrice(e.target.value.replace(/[^\d]/g, ""))
                }
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm"
                placeholder="5000"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Currency
              </label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm"
              >
                <option value="EGP">EGP</option>
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
                <option value="GBP">GBP</option>
              </select>
            </div>
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between">
              <label className="text-sm font-medium text-slate-700">
                Milestones
              </label>
              <button
                type="button"
                onClick={addMilestone}
                className="text-xs font-medium text-emerald-600 hover:text-emerald-700"
              >
                + Add milestone
              </button>
            </div>

            <div className="space-y-2">
              {milestones.map((m, i) => (
                <div
                  key={i}
                  className="rounded-xl border border-slate-200 bg-slate-50 p-3"
                >
                  <div className="grid gap-2 sm:grid-cols-3">
                    <input
                      value={m.title}
                      onChange={(e) => updateMilestone(i, "title", e.target.value)}
                      className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs"
                      placeholder={`Milestone #${i + 1} title`}
                    />
                    <input
                      value={m.amount}
                      onChange={(e) =>
                        updateMilestone(
                          i,
                          "amount",
                          e.target.value.replace(/[^\d]/g, "")
                        )
                      }
                      className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs"
                      placeholder="Amount"
                    />
                    <input
                      value={m.days}
                      onChange={(e) =>
                        updateMilestone(
                          i,
                          "days",
                          e.target.value.replace(/[^\d]/g, "")
                        )
                      }
                      className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs"
                      placeholder="Days"
                    />
                  </div>

                  {milestones.length > 1 && (
                    <div className="mt-2 text-right">
                      <button
                        type="button"
                        onClick={() => removeMilestone(i)}
                        className="text-xs text-slate-400 hover:text-red-500"
                      >
                        Remove
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-full border border-slate-300 px-3 py-1.5 text-xs"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={submitting || !!missing.length}
              className="rounded-full bg-emerald-500 px-4 py-1.5 text-xs font-medium text-white hover:bg-emerald-600 disabled:opacity-60"
            >
              {submitting ? "Sending…" : "Send offer"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Page ---------------- */

export default function ClientMessagesPage() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [authChecking, setAuthChecking] = useState(true);
  const [client, setClient] = useState<Client | null>(null);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loadingConversations, setLoadingConversations] = useState(true);
  const [selectedConversation, setSelectedConversation] =
    useState<Conversation | null>(null);

  const [messages, setMessages] = useState<MessageRow[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [newMessage, setNewMessage] = useState("");

  const [offerOpen, setOfferOpen] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Auth + client profile
  useEffect(() => {
    let cancelled = false;

    const checkAuth = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (cancelled) return;

      if (!user) {
        router.replace("/client/sign-in?next=/client/messages");
        return;
      }

      setCurrentUserId(user.id);

      const { data, error } = await supabase
        .from("clients")
        .select("client_id")
        .eq("auth_user_id", user.id)
        .single();

      if (cancelled) return;

      if (error || !data) {
        console.error("Client profile not found", error);
        router.replace("/client/sign-in?next=/client/messages");
        return;
      }

      setClient(data as Client);
      setAuthChecking(false);
    };

    checkAuth();

    return () => {
      cancelled = true;
    };
  }, [router]);

  // Load conversations (schema tolerant)
  useEffect(() => {
    if (authChecking || !client) return;

    let cancelled = false;

    const fetchWith = async (fields: string) => {
      return supabase
        .from("conversations")
        .select(
          `
          id,
          job_post_id,
          freelancer_id,
          created_at,
          last_message_at,
          job_posts:job_post_id ( title ),
          freelancer:freelancer_id ( ${fields} )
        `
        )
        .eq("client_id", client.client_id)
        .order("last_message_at", { ascending: false, nullsLast: true });
    };

    const loadConversations = async () => {
      setLoadingConversations(true);

      // try first/last scheme
      let { data, error } = await fetchWith(
        "first_name,last_name,personal_img_url"
      );
      // fall back to legacy full_name
      if (error && /column .* does not exist/i.test(error.message || "")) {
        ({ data, error } = await fetchWith("full_name,personal_img_url"));
      }

      if (cancelled) return;

      if (error) {
        console.error("Error loading conversations:", error.message);
        setConversations([]);
        setLoadingConversations(false);
        return;
      }

      const convs = (data || []) as Conversation[];
      setConversations(convs);
      setLoadingConversations(false);

      const qsId = searchParams.get("conversation");
      if (qsId) {
        const found = convs.find((c) => c.id === qsId);
        setSelectedConversation(found || convs[0] || null);
      } else {
        setSelectedConversation(convs[0] || null);
      }
    };

    loadConversations();
    return () => {
      cancelled = true;
    };
  }, [authChecking, client, searchParams]);

  // Load messages + realtime for selected conversation
  useEffect(() => {
    if (!selectedConversation) {
      setMessages([]);
      return;
    }

    let cancelled = false;

    const loadMessages = async () => {
      setLoadingMessages(true);
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .eq("conversation_id", selectedConversation.id)
        .order("created_at", { ascending: true });

      if (cancelled) return;

      if (error) {
        console.error("Error loading messages", error);
        setMessages([]);
      } else {
        setMessages((data || []) as MessageRow[]);
      }

      setLoadingMessages(false);
    };

    loadMessages();

    const channel = supabase
      .channel(`conversation-${selectedConversation.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `conversation_id=eq.${selectedConversation.id}`,
        },
        (payload) => {
          setMessages((prev) => [...prev, payload.new as MessageRow]);
        }
      )
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, [selectedConversation]);

  // Realtime conversation list changes for this client
  useEffect(() => {
    if (!client) return;

    const channel = supabase
      .channel(`client-conversations-${client.client_id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "conversations",
          filter: `client_id=eq.${client.client_id}`,
        },
        async (payload) => {
          const newId = (payload.new as any).id as string;

          const { data, error } = await supabase
            .from("conversations")
            .select(
              `
              id,
              job_post_id,
              freelancer_id,
              created_at,
              last_message_at,
              job_posts:job_post_id ( title ),
              freelancer:freelancer_id ( full_name, first_name, last_name, personal_img_url )
            `
            )
            .eq("id", newId)
            .single();

          if (error || !data) {
            console.error("Error fetching new conversation (client)", error);
            return;
          }

          const conv = data as Conversation;

          setConversations((prev) => {
            if (prev.some((c) => c.id === conv.id)) return prev;
            return [conv, ...prev];
          });

          setSelectedConversation((current) => current ?? conv);
        }
      )
      .on(
        "postgres_changes",
        {
          event: "DELETE",
          schema: "public",
          table: "conversations",
          filter: `client_id=eq.${client.client_id}`,
        },
        (payload) => {
          const deletedId = (payload.old as any).id as string;

          setConversations((prev) => prev.filter((c) => c.id !== deletedId));

          setMessages((prev) =>
            selectedConversation && selectedConversation.id === deletedId
              ? []
              : prev
          );

          setSelectedConversation((current) => {
            if (!current || current.id !== deletedId) return current;
            return null;
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [client, selectedConversation]);

  // Auto-scroll on message changes
  useEffect(() => {
    if (!selectedConversation) return;
    if (!messagesEndRef.current) return;
    messagesEndRef.current.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [selectedConversation, messages.length]);

  // Mark messages seen (client)
  useEffect(() => {
    if (!client || !selectedConversation || messages.length === 0) return;
    const markSeen = async () => {
      try {
        await supabase.rpc("mark_messages_seen_as_client");
      } catch (err) {
        console.error("mark_messages_seen_as_client error", err);
      }
    };
    markSeen();
  }, [client, selectedConversation, messages.length]);

  /* ---------------- Send message ---------------- */

  const handleSend = async (e: FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedConversation || !currentUserId) return;

    const body = newMessage.trim();
    setNewMessage("");

    const { error } = await supabase.from("messages").insert({
      conversation_id: selectedConversation.id,
      sender_auth_id: currentUserId,
      sender_role: "client",
      body,
    });

    if (error) {
      console.error("Error sending message", error);
      setNewMessage(body);
    } else {
      await supabase
        .from("conversations")
        .update({ last_message_at: new Date().toISOString() })
        .eq("id", selectedConversation.id);
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend(e as unknown as FormEvent);
    }
  };

  if (authChecking) {
    return (
      <main className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
        <div className="rounded-2xl bg-white border border-slate-200 shadow-sm px-6 py-4">
          <p className="text-sm text-slate-600">Checking your session…</p>
        </div>
      </main>
    );
  }

  const selectedFreelancerName = displayFreelancerName(
    selectedConversation?.freelancer
  );

  return (
    <main className="min-h-screen bg-slate-50">
      <div className="mx-auto max-w-6xl px-4 py-8">
        <header className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-slate-900">Messages</h1>
            <p className="text-sm text-slate-500">
              Chat with freelancers about your jobs.
            </p>
          </div>
          <button
            type="button"
            onClick={() => router.push("/client/dashboard")}
            className="rounded-full border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
          >
            Back to dashboard
          </button>
        </header>

        <div className="grid gap-4 md:grid-cols-[260px_minmax(0,1fr)]">
          {/* Sidebar */}
          <aside className="rounded-2xl border border-slate-200 bg-white p-3 flex flex-col">
            <div className="mb-2 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-800">
                Conversations
              </h2>
              <span className="text-[11px] text-slate-400">
                {loadingConversations
                  ? "Loading…"
                  : `${conversations.length} chats`}
              </span>
            </div>

            {conversations.length === 0 && !loadingConversations ? (
              <p className="mt-4 text-xs text-slate-500">
                You don&apos;t have any conversations yet.
              </p>
            ) : (
              <ul className="flex-1 space-y-1 overflow-y-auto">
                {conversations.map((c) => {
                  const isActive = selectedConversation?.id === c.id;
                  const lastTime = c.last_message_at || c.created_at;
                  const name = displayFreelancerName(c.freelancer);
                  const jobTitle =
                    c.job_posts?.title || `Job #${c.job_post_id}`;

                  return (
                    <li key={c.id}>
                      <button
                        type="button"
                        onClick={() => setSelectedConversation(c)}
                        className={`w-full rounded-xl px-3 py-2 text-left text-xs ${
                          isActive
                            ? "bg-emerald-50 border border-emerald-200"
                            : "hover:bg-slate-50 border border-transparent"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          {c.freelancer?.personal_img_url ? (
                            <img
                              src={c.freelancer.personal_img_url}
                              alt={name}
                              className="h-8 w-8 rounded-full object-cover border border-slate-200"
                            />
                          ) : (
                            <div className="h-8 w-8 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center text-[11px] font-semibold">
                              {initials(name)}
                            </div>
                          )}

                          <div className="flex-1 min-w-0">
                            <div className="font-medium text-slate-900 leading-tight truncate">
                              {name}
                            </div>
                            <div className="text-[11px] text-slate-500 leading-tight truncate">
                              {jobTitle}
                            </div>
                            <div className="mt-0.5 text-[10px] text-slate-400">
                              {new Date(lastTime).toLocaleString()}
                            </div>
                          </div>
                        </div>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </aside>

          {/* Messages pane */}
          <section className="rounded-2xl border border-slate-200 bg-white flex flex-col h-[520px]">
            {selectedConversation ? (
              <>
                <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
                  <div>
                    <p className="text-sm font-semibold text-slate-900">
                      {selectedConversation.job_posts?.title ||
                        `Job #${selectedConversation.job_post_id}`}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Chat with {selectedFreelancerName}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => setOfferOpen(true)}
                    className="relative z-10 inline-flex items-center rounded-full bg-emerald-500 px-3 py-1.5 text-xs font-medium text-white shadow-sm hover:bg-emerald-600"
                    title="Send offer / Create contract"
                  >
                    Send offer / Create contract
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
                  {loadingMessages ? (
                    <p className="text-xs text-slate-500">
                      Loading messages…
                    </p>
                  ) : messages.length === 0 ? (
                    <p className="text-xs text-slate-500">
                      No messages yet. Start a conversation 👋
                    </p>
                  ) : (
                    messages.map((m) => {
                      const isOwn = m.sender_auth_id === currentUserId;
                      return (
                        <div
                          key={m.id}
                          className={`flex ${
                            isOwn ? "justify-end" : "justify-start"
                          }`}
                        >
                          <div
                            className={`max-w-[75%] rounded-2xl px-3 py-2 text-sm ${
                              isOwn
                                ? "bg-emerald-500 text-white"
                                : "bg-slate-100 text-slate-900"
                            }`}
                          >
                            <p className="whitespace-pre-wrap">{m.body}</p>
                            <span className="mt-1 block text-[10px] text-slate-400 text-right">
                              {new Date(m.created_at).toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </span>
                          </div>
                        </div>
                      );
                    })
                  )}
                  <div ref={messagesEndRef} />
                </div>

                <form
                  onSubmit={handleSend}
                  className="border-t border-slate-200 px-4 py-3 flex items-end gap-2"
                >
                  <textarea
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={handleKeyDown}
                    rows={1}
                    placeholder="Type your message…"
                    className="flex-1 resize-none rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-emerald-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  />
                  <button
                    type="submit"
                    className="inline-flex items-center rounded-full bg-emerald-500 px-4 py-2 text-xs font-medium text-white shadow-sm hover:bg-emerald-600 disabled:opacity-60"
                    disabled={!newMessage.trim()}
                  >
                    Send
                  </button>
                </form>
              </>
            ) : (
              <div className="flex flex-1 items-center justify-center text-sm text-slate-500">
                Select a conversation from the left to start chatting.
              </div>
            )}
          </section>
        </div>
      </div>

      {/* Inline offer modal */}
      <OfferInlineModal
        open={offerOpen}
        onClose={() => setOfferOpen(false)}
        clientId={client?.client_id ?? null}
        freelancerId={selectedConversation?.freelancer_id ?? null}
        jobPostId={selectedConversation?.job_post_id ?? null}
        conversationId={selectedConversation?.id ?? null}
        currentUserId={currentUserId}
      />
    </main>
  );
}
